const express = require('express');
const path = require('path');

const app = express();

// Configurar la carpeta de archivos estáticos para servir los archivos de la aplicación Vue
app.use(express.static(path.join(__dirname, 'dist')));

// Configurar la ruta de la aplicación
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

// Puerto en el que el servidor escuchará las solicitudes
const port = process.env.PORT || 3000;

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor escuchando en el puerto ${port}`);
});
